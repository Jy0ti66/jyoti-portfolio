import { motion } from "framer-motion";
import { Award, Calendar } from "lucide-react";

const CertificationsSection = () => {
  return (
    <section id="certifications" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Credentials</p>
          <h2 className="section-heading mb-14">
            <span className="gradient-text">Training</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass glow-border group hover:border-primary/40 transition-all duration-500 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

          <div className="relative p-8 md:p-10 flex flex-col md:flex-row gap-8">
            <div className="shrink-0">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors duration-300">
                <Award className="w-7 h-7 text-primary" />
              </div>
            </div>

            <div className="flex-1 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
                <div>
                  <h3 className="font-display font-semibold text-xl group-hover:text-primary transition-colors duration-300">
                    Object Oriented Programming with C++
                  </h3>
                  <p className="text-primary/70 font-mono text-sm mt-1">CipherSchools</p>
                </div>
                <span className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground shrink-0">
                  <Calendar className="w-3.5 h-3.5" />
                  Jul 2025 – Aug 2025
                </span>
              </div>

              <p className="text-muted-foreground text-sm leading-relaxed max-w-2xl">
                Completed a Training in C++ with Object-Oriented Programming, focusing on writing clean, modular, and efficient code. Gained hands-on experience with classes, objects, constructors, inheritance, and polymorphism to design real-world software solutions. Built OOP-based mini-projects such as Bank Management applying full OOP design principles.
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                <span className="text-xs font-mono px-3 py-1.5 rounded-full bg-secondary/80 text-secondary-foreground/80 group-hover:bg-primary/10 group-hover:text-primary transition-colors duration-300">
                  OOP Concepts
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CertificationsSection;
