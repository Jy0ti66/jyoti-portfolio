import { motion } from "framer-motion";
import { Github, ArrowUpRight } from "lucide-react";

const projects = [
  {
    title: "Cloud Cost Analysis using AWS Pricing Calculator",
    description:
      "Designed and analyzed cloud infrastructure costs using the AWS Pricing Calculator. Evaluated EC2, S3, and other AWS services across configurations to estimate monthly expenses and optimize cost efficiency for scalable cloud deployments.",
    github: "https://github.com/Jy0ti66/cloud-cost-analysis-aws",
    tags: ["AWS Pricing Calculator", "Amazon EC2", "Amazon S3", "Cloud Infrastructure Planning"],
    number: "01",
  },
  {
    title: "Smart Ride Matching System",
    description:
      "A system that matches riders efficiently using optimized logic and real-time data handling. Implements Dijkstra's algorithm with priority queues and HashMaps for efficient shortest-path computation.",
    github: "https://github.com/Jy0ti66/smart-ride-matching-system",
    tags: ["Java", "Graphs", "Dijkstra", "Priority Queue", "HashMap"],
    number: "02",
  },
  {
    title: "Apache CloudStack Deployment",
    description:
      "End-to-end deployment of a private cloud infrastructure using Apache CloudStack on VMware Workstation. Configured networking, storage, and compute resources via Ubuntu CLI.",
    tags: ["Apache CloudStack", "Ubuntu", "VMware", "Cloud Infra"],
    number: "03",
  },
];

const ProjectsSection = () => {
  return (
    <section id="projects" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Work</p>
          <h2 className="section-heading mb-14">
            Featured <span className="gradient-text">Projects</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.12 }}
              className="glass glow-border group relative overflow-hidden hover:border-primary/40 hover:scale-[1.02] transition-all duration-500 flex flex-col"
            >
              {/* Hover glow overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="relative p-7 flex flex-col flex-1 gap-4">
                {/* Number accent */}
                <span className="font-mono text-4xl font-bold text-primary/15 group-hover:text-primary/30 transition-colors duration-500 select-none">
                  {project.number}
                </span>

                {/* Content */}
                <div className="flex-1 flex flex-col gap-3">
                  <h3 className="font-display font-semibold text-lg group-hover:text-primary transition-colors duration-300 leading-snug">
                    {project.title}
                  </h3>

                  <p className="text-muted-foreground text-sm leading-relaxed flex-1">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs font-mono px-2.5 py-1 rounded-full bg-secondary/80 text-secondary-foreground/80 group-hover:bg-primary/10 group-hover:text-primary transition-colors duration-300"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* View Code button */}
                {project.github && (
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-mono text-primary/70 hover:text-primary transition-colors duration-300 mt-auto pt-2"
                  >
                    <Github className="w-4 h-4" />
                    View Code
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
