import { motion } from "framer-motion";
import { Cloud, Rocket, Target } from "lucide-react";

const learningTopics = [
  "AWS core services (EC2, S3, IAM)",
  "CI/CD pipelines and automation",
  "Terraform for Infrastructure as Code",
  "Docker containerization",
  "Linux and shell scripting",
];

const deployments = [
  "DevOps CI/CD mini pipeline",
  "S3 static website hosting",
  "EC2 Apache web server setup",
  "Terraform AWS infrastructure",
];

const CloudJourneySection = () => {
  return (
    <section id="cloud-journey" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Growth</p>
          <h2 className="section-heading mb-4">
            Cloud Learning <span className="gradient-text">Journey</span>
          </h2>
          <p className="text-muted-foreground mb-14 max-w-xl">
            My structured path to becoming cloud-ready
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-10">
          {/* Currently Learning */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="glass glow-border group hover:border-primary/40 transition-all duration-500 p-8 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            <div className="relative">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Cloud className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display font-semibold text-lg">Currently Learning</h3>
              </div>
              <ul className="space-y-3">
                {learningTopics.map((topic, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                    {topic}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Hands-on Deployments */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="glass glow-border group hover:border-primary/40 transition-all duration-500 p-8 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            <div className="relative">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Rocket className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display font-semibold text-lg">Hands-on Deployments</h3>
              </div>
              <ul className="space-y-3">
                {deployments.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>

        {/* Goal Quote */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="glass glow-border p-8 relative overflow-hidden group hover:border-primary/40 transition-all duration-500"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
          <div className="relative flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Target className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-display font-semibold text-lg mb-3">Goal</h3>
              <p className="text-muted-foreground text-sm leading-relaxed italic">
                "My goal is to transform my projects into scalable, cloud-deployed applications and build a strong foundation for a career in cloud engineering."
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CloudJourneySection;
