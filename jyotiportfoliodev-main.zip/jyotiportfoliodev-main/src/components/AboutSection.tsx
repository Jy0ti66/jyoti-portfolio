import { motion } from "framer-motion";

const aboutPoints = [
  "Computer Science student focused on cloud computing and DevOps",
  "Passionate about building scalable, real-world applications",
  "Interested in cloud technologies, system design, and automation",
  "Continuously learning modern tools and frameworks",
  "Hands-on approach — learning by building projects",
];

const AboutSection = () => {
  return (
    <section id="about" className="py-24 px-6">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Introduction</p>
          <h2 className="section-heading mb-10">
            About <span className="gradient-text">Me</span>
          </h2>
        </motion.div>

        <motion.ul
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="space-y-4"
        >
          {aboutPoints.map((point, i) => (
            <li key={i} className="flex items-start gap-3 text-muted-foreground text-base leading-relaxed">
              <span className="w-2 h-2 rounded-full bg-primary mt-2 shrink-0" />
              {point}
            </li>
          ))}
        </motion.ul>
      </div>
    </section>
  );
};

export default AboutSection;
