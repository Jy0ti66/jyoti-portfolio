import { motion } from "framer-motion";
import { GraduationCap, MapPin, Calendar } from "lucide-react";

const education = [
  {
    institution: "Lovely Professional University",
    location: "Punjab, India",
    degree: "Bachelor of Technology in Computer Science and Engineering",
    duration: "Aug 2023 – Jun 2027",
    score: "CGPA: 6.3",
  },
  {
    institution: "Hellen School",
    location: "Sitamarhi, Bihar",
    degree: "Intermediate",
    duration: "Apr 2021 – Mar 2022",
    score: "Percentage: 70%",
  },
  {
    institution: "DAV Public School",
    location: "Sitamarhi, Bihar",
    degree: "Matriculation",
    duration: "Apr 2019 – Mar 2020",
    score: "Percentage: 84%",
  },
];

const EducationSection = () => {
  return (
    <section id="education" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Background</p>
          <h2 className="section-heading mb-14">
            My <span className="gradient-text">Education</span>
          </h2>
        </motion.div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 md:left-8 top-0 bottom-0 w-px bg-border hidden md:block" />

          <div className="space-y-8">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative md:pl-20"
              >
                {/* Timeline dot */}
                <div className="absolute left-4 md:left-6 top-8 w-4 h-4 rounded-full bg-primary/20 border-2 border-primary hidden md:flex items-center justify-center z-10">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                </div>

                <div className="glass glow-border group hover:border-primary/40 transition-all duration-500 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                  <div className="relative p-8 flex flex-col sm:flex-row gap-6">
                    <div className="shrink-0">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors duration-300">
                        <GraduationCap className="w-6 h-6 text-primary" />
                      </div>
                    </div>

                    <div className="flex-1 space-y-2">
                      <h3 className="font-display font-semibold text-lg group-hover:text-primary transition-colors duration-300">
                        {edu.institution}
                      </h3>
                      <p className="text-sm text-foreground/80">{edu.degree}</p>
                      <div className="flex flex-wrap gap-4 text-xs font-mono text-muted-foreground">
                        <span className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-primary/60" />
                          {edu.location}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-primary/60" />
                          {edu.duration}
                        </span>
                      </div>
                      <span className="inline-block text-xs font-mono px-3 py-1.5 rounded-full bg-secondary/80 text-secondary-foreground/80 group-hover:bg-primary/10 group-hover:text-primary transition-colors duration-300 mt-2">
                        {edu.score}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
