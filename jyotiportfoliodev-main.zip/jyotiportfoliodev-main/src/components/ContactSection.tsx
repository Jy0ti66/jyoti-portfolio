import { motion } from "framer-motion";
import { Mail, Github, Linkedin } from "lucide-react";

const ContactSection = () => {
  return (
    <section id="contact" className="py-24 px-6">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Contact</p>
          <h2 className="section-heading mb-4">
            Get In <span className="gradient-text">Touch</span>
          </h2>
          <p className="text-muted-foreground">
            Let's connect and discuss opportunities
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex flex-col sm:flex-row flex-wrap justify-center gap-6 text-sm"
        >
          <a
            href="mailto:jyotikumari09072004@gmail.com"
            className="glass glow-border group hover:border-primary/40 transition-all duration-500 px-6 py-5 flex items-center gap-3 rounded-lg"
          >
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors duration-300">
              <Mail className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-mono">Email</p>
              <p className="text-foreground group-hover:text-primary transition-colors duration-300">jyotikumari09072004@gmail.com</p>
            </div>
          </a>

          <a
            href="https://github.com/Jy0ti66"
            target="_blank"
            rel="noopener noreferrer"
            className="glass glow-border group hover:border-primary/40 transition-all duration-500 px-6 py-5 flex items-center gap-3 rounded-lg"
          >
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors duration-300">
              <Github className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-mono">GitHub</p>
              <p className="text-foreground group-hover:text-primary transition-colors duration-300">Jy0ti66</p>
            </div>
          </a>

          <a
            href="https://www.linkedin.com/in/jyoti-kumari6/"
            target="_blank"
            rel="noopener noreferrer"
            className="glass glow-border group hover:border-primary/40 transition-all duration-500 px-6 py-5 flex items-center gap-3 rounded-lg"
          >
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors duration-300">
              <Linkedin className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-mono">LinkedIn</p>
              <p className="text-foreground group-hover:text-primary transition-colors duration-300">jyoti-kumari6</p>
            </div>
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default ContactSection;
