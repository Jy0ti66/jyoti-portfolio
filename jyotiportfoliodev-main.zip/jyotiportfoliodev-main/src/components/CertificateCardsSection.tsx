import { motion } from "framer-motion";
import { Award, ExternalLink, Calendar, Building2 } from "lucide-react";

const certificates = [
  {
    title: "CPP with OOPs",
    organization: "CipherSchools",
    date: "Jul 2025 – Aug 2025",
    link: "https://drive.google.com/file/d/1EUJKnURjuzuIXnNJ6FqM-2M4Qnry7Zvf/view?usp=sharing",
  },
  {
    title: "Computational Theory",
    organization: "Infosys",
    date: "Aug 2025",
    link: "https://drive.google.com/file/d/1YHXZEgy32NflFfvzlVbcqF_OP3dXOTBd/view?usp=sharing",
  },
  {
    title: "Java Programming",
    organization: "Neocolab",
    date: "Jan 2025 – May 2025",
    link: "https://drive.google.com/file/d/1ZKQ4P6Qg4Fl-1WrozAk9JmKi_Q__FhEN/view?usp=sharing",
  },
];

const CertificateCardsSection = () => {
  return (
    <section id="certificates" className="py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-2">Achievements</p>
          <h2 className="section-heading mb-14">
            My <span className="gradient-text">Certifications</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {certificates.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass glow-border group hover:border-primary/40 transition-all duration-500 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.03] to-accent/[0.03] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <div className="relative p-8 flex flex-col gap-5">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors duration-300">
                  <Award className="w-6 h-6 text-primary" />
                </div>

                <div className="space-y-3">
                  <h3 className="font-display font-semibold text-lg group-hover:text-primary transition-colors duration-300">
                    {cert.title}
                  </h3>

                  <div className="flex flex-col gap-1.5 text-sm text-muted-foreground">
                    <span className="flex items-center gap-2">
                      <Building2 className="w-3.5 h-3.5 text-primary/60" />
                      {cert.organization}
                    </span>
                    <span className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-primary/60" />
                      {cert.date}
                    </span>
                  </div>
                </div>

                <a
                  href={cert.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-mono text-primary hover:text-primary/80 transition-colors duration-300 mt-auto pt-2"
                >
                  View Certificate
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CertificateCardsSection;
