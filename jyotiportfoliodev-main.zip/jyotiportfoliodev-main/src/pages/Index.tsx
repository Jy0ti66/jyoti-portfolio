import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import EducationSection from "@/components/EducationSection";
import ProjectsSection from "@/components/ProjectsSection";
import CloudJourneySection from "@/components/CloudJourneySection";
import CertificationsSection from "@/components/CertificationsSection";
import CertificateCardsSection from "@/components/CertificateCardsSection";
import SkillsSection from "@/components/SkillsSection";
import ContactSection from "@/components/ContactSection";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <EducationSection />
      <ProjectsSection />
      <CloudJourneySection />
      <CertificationsSection />
      <CertificateCardsSection />
      <SkillsSection />
      <ContactSection />
      <footer className="py-10 text-center border-t border-border">
        <p className="font-display font-semibold text-foreground">Jyoti Kumari</p>
        <p className="text-xs text-muted-foreground mt-3">
          © 2026 Jyoti Kumari. All rights reserved.
        </p>
      </footer>
    </div>
  );
};

export default Index;
